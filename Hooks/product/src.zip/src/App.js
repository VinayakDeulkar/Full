import './App.css';
import Navigation from './Component/Navigation';


function App() {
  
  return (
    <div >
      
       <Navigation/>
      
      
    </div>
  );
}

export default App;
