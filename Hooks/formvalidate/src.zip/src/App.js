
import { Col, Container, Row } from 'react-bootstrap';
import './App.css';
import FormCode from './Component/FormCode';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Card } from '@mui/material';
function App() {
  return (
    <div className="App">
      
        <Container>
          <Row>
            <Col lg={2}/>
            <Col lg={8} className="dark">
              <Card className="margin">
                <FormCode/>
              </Card>
            </Col>
          </Row>
         </Container>
      
    </div>
  );
}

export default App;
