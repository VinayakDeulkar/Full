
import { Grid,Button, CardHeader, Typography } from '@mui/material';
import React,{useState} from 'react'
import { Form } from 'react-bootstrap'
import {  useDispatch, useSelector } from "react-redux";

export default function FormCode(props) {
    const [Name, setName] = useState('');
    const [Email, setEmail] = useState('');
    const [Password, setPassword] = useState('');
    const [MobileNumber, setMobileNumber] = useState('');
    const mydata=useSelector((state)=>state)
    console.log(mydata);
    const dispatch = useDispatch()
    
    return (
        <div>
            <Form>
                <Typography variant="h5">Register</Typography>
                <Form.Group>
                        Name:<Form.Control placeholder="Name" value={Name}  onChange={(e)=>{setName(e.target.value)}} name="Name"/>
                </Form.Group>
                <Form.Group>
                        Email:<Form.Control placeholder="Email " value={Email} onChange={(e)=>{setEmail(e.target.value)}} name="Email"/>
                </Form.Group>
                <Form.Group>
                        Password:<Form.Control placeholder="Password" value={Password} onChange={(e)=>{setPassword(e.target.value)}} name="Password"/>
                </Form.Group>
                <Form.Group>
                        Mobile Number:<Form.Control placeholder="Mobile Number" value={MobileNumber} onChange={(e)=>{setMobileNumber(e.target.value)}} name="MobileNumber"/>
                </Form.Group>
                
                <Button variant="contained" onClick={()=>dispatch({type:"Submit",payload:{Name:Name,Email:Email,Password:Password,MobileNumber:MobileNumber}})} >Submit</Button>
            </Form>
        </div>
    )
}
